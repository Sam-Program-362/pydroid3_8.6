import sys
import jedi
from struct import unpack

def recv_basic(torecv):
    total_data=[]
    rcvd = 0
    global stdin	
    while rcvd<torecv:
        data = stdin.read(torecv-rcvd)
        rcvd += len(data)
        total_data.append(data)
    if (sys.version_info[0]>2):
        return b''.join(total_data).decode('utf-8')
    else:
        return ''.join(total_data)

if (sys.version_info[0]>2):
	stdin = sys.stdin.buffer
else:
	stdin = sys.stdin

while (1==1):
	

	mode = unpack('<I', stdin.read(4))[0]

	num_lines = unpack('<I', stdin.read(4))[0]
	char_num = unpack('<I', stdin.read(4))[0]
	text_len = unpack('<I', stdin.read(4))[0]
	
	fname_len = unpack('<I', stdin.read(4))[0]
	fname = recv_basic(fname_len)

	source = recv_basic(text_len)	

	#modes:
	#	1 - autocomplete
	#	2 - get_names
	#	3 - go_to_assignments

	if mode==1:
		#autocomplete
		
		res = ''

		try:
			script = jedi.Script(source, path=fname)
			completions = script.complete(num_lines, char_num)			    
			for a in completions:
				res = res + a.name + "###iiec_splitter###" + a.complete + '\n'

		except Exception as e:
			print(e, file=sys.stderr)
			sys.stderr.flush()
			#problemes
			res = ''
		res = res + "###iiec_end_of_output###" + '\n'
		sys.stdout.write(res)
		sys.stdout.flush()

	if mode==2:
		#get names
	
		res = ''

		try:
			for a in jedi.Script(source, path=fname).get_names():
				res = res + '###iiec_sep###'+a.name
				res = res + '###iiec_sep###'+a.description
				res = res + '###iiec_sep###'+a.docstring()
				res = res + '###iiec_sep###'+a.type
				res = res + '###iiec_sep###'+str(a.column)
				res = res + '###iiec_sep###'+str(a.line)  + '\n' + '###iiec_next_name###' + '\n'
		except Exception as e:
			print(e, file=sys.stderr)
			sys.stderr.flush()
			#problemes
			res = ''

		res = res + "###iiec_end_of_output###" + '\n'
		sys.stdout.write(res)
		sys.stdout.flush()

	if mode==3:
		#goto_assignments

		res = ''

		try:
			script = jedi.Script(source, path=fname)
			assigments = script.goto(num_lines, char_num)
			for a in assigments:
				res = res + '###iiec_sep###'+a.name
				res = res + '###iiec_sep###'+a.description
				res = res + '###iiec_sep###'+a.docstring()
				res = res + '###iiec_sep###'+a.type
				res = res + '###iiec_sep###'+str(a.column)
				res = res + '###iiec_sep###'+str(a.line)  + '\n' + '###iiec_next_name###' + '\n'
		except Exception as e:
			print(e, file=sys.stderr)
			sys.stderr.flush()
			#problemes
			res = ''

		res = res + "###iiec_end_of_output###" + '\n'
		sys.stdout.write(res)
		sys.stdout.flush()

	if mode==4:
		#goto_definitions

		res = ''

		try:
			script = jedi.Script(source, path=fname)
			definitions = script.infer(num_lines, char_num)
			for a in definitions:
				res = res + '###iiec_sep###'+a.name
				res = res + '###iiec_sep###'+a.description
				res = res + '###iiec_sep###'+a.docstring()
				res = res + '###iiec_sep###'+a.type
				res = res + '###iiec_sep###'+str(a.column)
				res = res + '###iiec_sep###'+str(a.line)  + '\n' + '###iiec_next_name###' + '\n'
		except Exception as e:
			print(e, file=sys.stderr)
			sys.stderr.flush()
			#problemes
			res = ''

		res = res + "###iiec_end_of_output###" + '\n'
		sys.stdout.write(res)
		sys.stdout.flush()


