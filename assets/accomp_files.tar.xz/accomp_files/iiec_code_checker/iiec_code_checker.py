import io
import sys
import os

if (sys.version_info[0]>2):
	import builtins as __builtin__
	stdin = sys.stdin.buffer
else:
	import __builtin__
	stdin = sys.stdin



from struct import unpack

bkpopen=__builtin__.open

source_code = ''



def recv_basic(torecv):
	total_data=[]
	rcvd = 0
	while rcvd<torecv:
		data = stdin.read(torecv-rcvd)
		rcvd += len(data)
		total_data.append(data)
	
	if (sys.version_info[0]>2):
		return b''.join(total_data)		
	else:
		return ''.join(total_data)

fname = 'TOBECHANGED'
def myopen(*args, **kwargs):
	global fname
	if args[0]==fname:
		if (sys.version_info[0]>2) and (len(args)<2 or not 'b' in args[1]):
			return io.StringIO(str(source_code, 'utf-8'))		
		else:
			return io.BytesIO(source_code) 
	else:
		return bkpopen(*args,**kwargs)

__builtin__.open=myopen
sys.argv[:]=['pylint','TOBECHANGED','--persistent=n','--reports=n','--output-format=parseable','--msg-template=\'{C}:{line}:{column}:{obj}:{msg}:{msg_id}\''] + sys.argv[1:]

import pylint

def run_with_no_exit():
	from astroid import MANAGER
	# MANAGER.clear_cache()
	# Smartass decaching algorithm
	todelete=[]
	for x in MANAGER.astroid_cache:
		f=str(MANAGER.astroid_cache[x].file)
		if f and not ('/lib/python' in f and '/ru.iiec.pydroid' in f) and '/' in f:
			todelete+=[x]
	for x in todelete:
		del MANAGER.astroid_cache[x]
	from pylint.lint import Run
	Run(sys.argv[1:], exit=False)


while(1==1):
	text_len = unpack('<I', stdin.read(4))[0]
	fname_len = unpack('<I', stdin.read(4))[0]
	fname = recv_basic(fname_len).decode('utf-8')
	source_code = recv_basic(text_len)
	
	if len(fname)==0:
		fname = "/system/bin/linker"
		if os.path.isfile("/system/bin/linker64"):
			fname = "/system/bin/linker64"
	
	sys.argv[1] = fname
	
	run_with_no_exit()
	sys.stdout.write('===iiec_spec_sepa_string_c2782e1248daf7d3a9fa0eccc2c3870e===\n')
	sys.stdout.flush()



